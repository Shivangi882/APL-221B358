class Voice {
    public void prepareVoice() {
        System.out.println("Preparing voice...");
    }
    
    public void hear() {
        System.out.println("Hearing the voice...");
    }
}
