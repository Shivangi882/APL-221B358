class Pig extends Animal {
    void makeVoice() {
        System.out.println("Pig says Oink-oink!");
    }
}