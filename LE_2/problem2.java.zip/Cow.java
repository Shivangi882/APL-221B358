class Cow extends Animal {
    void makeVoice() {
        System.out.println("Cow says Moo-moo!");
    }
}