class Dog extends Animal {
    void makeVoice() {
        System.out.println("Dog says bhow-bhow!");
    }
}