abstract class Animal {
    abstract void makeVoice();
}