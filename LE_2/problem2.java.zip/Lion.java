class Lion extends Animal {
    void makeVoice() {
        System.out.println("Lion says Roar!");
    }
}