class Goat extends Animal {
    void makeVoice() {
        System.out.println("Goat says Meah-Meah!");
    }
}