class Child extends Mother {
    
    
}


