class Child extends Mother {
    @Override
    void show() {
        System.out.println("Hello JUET");
    }
}