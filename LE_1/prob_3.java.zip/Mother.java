class Mother {
   
    public void show() {
        System.out.println("Mother's show()");
    }

    
    public static void showStatic() {
        System.out.println("Mother's static show()");
    }
}