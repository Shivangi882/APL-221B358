class Child extends Mother {
   
    public void show() {
        System.out.println("Child's show()");
    }

    
    public static void showStatic() {
        System.out.println("Child's static show()");
    }
}